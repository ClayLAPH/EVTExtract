CREATE VIEW dbo.[uvw_Extract_COVID_INCIDENT]
AS
SELECT  [PR_PHTYPE]												AS 'Record_Type'
        , [PR_ROWID]											AS 'Row_ID'
		, [PR_PERSONDR]											AS 'Incident_Person_link'
        , [PR_INCIDENTID]										AS 'Incident_ID'
        , [PR_DISEASE]											AS 'Disease'
        , [PR_DISEASESHORTNAME]									AS 'Disease_Short_Name'
        , [PR_OTHERDISEASE]										AS 'Other_Disease'
        , [PR_DISEASEGROUPS]									AS 'Disease_Groups'
        , [Age]													AS 'Age'
        , [PR_CENSUSTRACT]										AS 'Census_Tract'
        , [Country_of_Birth]									AS 'Country_of_Birth'
        , (
			CASE
			WHEN [PR_ISPREGNANT] = 0 THEN 'N'
			WHEN [PR_ISPREGNANT] = 1 THEN 'Y' 
			ELSE 'U'
			END
		) AS 'Is_Pregnant'
        , try_CONVERT(datetime,[PR_EXPECTEDDELIVERYDATE])       AS 'Expected_Delivery_Date'
        , [Marital_Status]                                      AS 'Marital_Status'
        , [Parent_or_Guardian_Name]                             AS 'Parent_or_Guardian_Name'
        , [Medical_Record_Number]                               AS 'Medical_Record_Number'
        , [Occupation_Setting_Type]                             AS 'Occupation_Setting_Type'
        , [PR_DISTRICT]                                         AS 'District'
        , [Health_District_Number]                              AS 'Health_District_Number'
				, try_CONVERT(datetime,[PR_ONSETDATE])                  AS 'Onset_Date_Date_of_Contact'
        , [PR_PROCESSSTATUS]                                    AS 'Process_Status'
        , [Secondary_District]                                  AS 'Secondary_District'
        , [PR_NURSEINVESTIGATOR]                                AS 'Investigator'
        , try_CONVERT(datetime,[PR_LABSPECIMENCOLLECTEDDATE])   AS 'Lab_Specimen_Collection_Date'
		, (
			CASE
			WHEN [PR_REPORTEDBYWEB] = 0 THEN 'False'
			WHEN [PR_REPORTEDBYWEB] = 1 THEN 'True'
			ELSE NULL 
			END
		) AS 'Web_Report'                      
        , [Lab_Report]                                          AS 'Lab_Report'
        , [Type_of_Contact]                                     AS 'Type_of_Contact'
        , try_CONVERT(datetime,[PR_DATEREPORTEDBY])             AS 'Date_Reported_By'
        , try_CONVERT(datetime,[PR_DATEOFLABREPORT])            AS 'Date_of_Lab_Report'
        , [Diagnostic_Specimen_Types]                           AS 'Diagnostic_Specimen_Types'
        , [Priority]                                            AS 'Priority'
        , try_CONVERT(datetime,[PR_LABSPECIMENRESULTDATE])      AS 'Lab_Specimen_Result_Date'
        , try_CONVERT(datetime,[PR_DATEOFDIAGNOSIS])            AS 'Date_of_Diagnosis'
        , [Report_Source]                                       AS 'Report_Source'
        , [Provider_Name]                                       AS 'Provider_Name'
        , [PR_NAMEOFSUBMITTER]                                  AS 'Submitter_Name'
        , try_CONVERT(datetime,[PR_DATEOFDEATH])                AS 'Date_of_Death'
        , [Imported_Status]                                     AS 'Imported_Status'
        , [PR_LABORATORY]                                       AS 'Laboratory'
        , try_CONVERT(datetime,[PR_DATEINVESTIGATORRECEIVED])   AS 'Date_Received'
        , [PR_RESOLUTIONSTATUS]                                 AS 'Resolution_Status'
        , [Additional_Provider]                                 AS 'Additional_Provider'
        , [Final_Disposition]                                   AS 'Final_Disposition'
        , [Additional_Laboratory]                               AS 'Additional_Laboratory'
        , [Created_By]                                          AS 'Created_By'
        , try_CONVERT(datetime,[PR_CREATEDATE])                 AS 'Date_Created'
        , try_CONVERT(TIME, [PR_CREATEDATE])                    AS 'Time_Created'
        , try_CONVERT(datetime,[PR_DATESUBMITTED])              AS 'Date_Submitted'
        , try_CONVERT(TIME,[PR_DATESUBMITTED])                  AS 'Time_Submitted'
        , [PR_TRANSMISSIONSTATUS]                               AS 'Transmission_Status'
        , try_CONVERT(datetime,[PR_EPISODEDATE])                AS 'Episode_Date'
        , try_CONVERT(datetime,[PR_DATESENT])                   AS 'Date_Sent'
		,	(
			CASE
			WHEN [PR_ISINDEXCASE] = 0 THEN 'False'
			WHEN [PR_ISINDEXCASE] = 1 THEN 'True'
			ELSE NULL
			END
		)														AS 'Index_Case'
        , [PR_CLUSTERID]                                        AS 'Cluster_ID'
        , try_CONVERT(datetime,[PR_CLOSEDDATE])                 AS 'Closed_Date'
        , try_CONVERT(datetime,[PR_LASTCDCUPDATE])              AS 'Last_CDC_Update'
		,	(
			CASE
			WHEN [PR_ISPATIENTDIEDOFTHEILLNESS] = 0 THEN 'False'
			WHEN [PR_ISPATIENTDIEDOFTHEILLNESS] = 1 THEN 'True'
			ELSE NULL
			END
			)													AS 'Patient_Died_of_this_Illness'
        , try_CONVERT(datetime,[PR_DATEADMITTED])               AS 'Date_Admitted'                          		
		,	(
			CASE
			WHEN [PR_ISPATIENTHOSPITALIZED] = 0 THEN 'False'
			WHEN [PR_ISPATIENTHOSPITALIZED] = 1 THEN 'True'
			ELSE NULL
			END
			)													AS 'Patient_Hospitalized'
        , [PR_HOSPITAL]                                         AS 'Hospital'
        , [PR_HOSPITALDR]                                       AS 'Hospital_DR'
        ,	(
			CASE
			WHEN [PR_INPATIENT] = 0 THEN 'False'
			WHEN [PR_INPATIENT] = 1 THEN 'True'
			ELSE NULL 
			END
			)			                                        AS 'Inpatient'
		,	(
			CASE
			WHEN [PR_OUTPATIENT] = 0 THEN 'False'
			WHEN [PR_OUTPATIENT] = 1 THEN 'True'
			ELSE NULL 
			END
			)			                                        AS 'Outpatient'
        , try_CONVERT(datetime,[PR_DATEDISCHARGED]) AS 'Date_Discharged'
        , try_CONVERT(datetime,[Date_Last_Edited])  AS 'Date_Last_Edited'
        , [Outbreak_IDs]                                        AS 'Outbreak_IDs'
        , [PR_NOTES]                                            AS 'Notes_Remarks'
        , [Suspected_Exposure_Types]                            AS 'Suspected_Exposure_Types'
        , [Most_Recent_Lab_Result]                              AS 'Most_Recent_Lab_Result'
        , [Most_Recent_Lab_Result_Value]                        AS 'Most_Recent_Lab_Result_Value'
        , [Lab_Report_Test_Name]                                AS 'Lab_Report_Test_Name'
        , [Lab_Report_Notes]                                    AS 'Lab_Report_Notes'
        , [ImportedBy]                                          AS 'ImportedBy'
        , [American_Indian_or_Alaska_Native]                    AS 'American_Indian_or_Alaska_Native_Specify'
        , [Asian___Specify]                                     AS 'Asian_Specify'
        , [Black_or_African_American___Spec]                    AS 'Black_or_African_American_Specify'
        , [Native_Hawaiian_or_Other_Pacific]                    AS 'Native_Hawaiian_or_Other_Pacific_Islander_Specify'
        , [Other___Specify]                                     AS 'Other_Specify'
        , [Unknown___Specify]                                   AS 'Unknown_Specify'
        , [White___Specify]                                     AS 'White_Specify'
FROM   dbo.[COVID_INCIDENT] with (nolock)

