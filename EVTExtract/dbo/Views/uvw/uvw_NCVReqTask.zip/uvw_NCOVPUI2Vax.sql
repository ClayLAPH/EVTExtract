CREATE VIEW dbo.uvw_NCOVPUI2Vax
AS
SELECT  
  try_cast(NCOVPUI2Vax1Date AS DATETIME) AS NCOVPUI2Vax1Date,
  try_cast(NCOVPUI2Vax2Date AS DATETIME) AS NCOVPUI2Vax2Date,
  try_cast(NCOVPUI2Vax3Date AS DATETIME) AS NCOVPUI2Vax3Date,
  NCOVPUI2Vax3DateUnk,
  NCOVPUI2Vax2DateUnk,
  NCOVPUI2Vax1DateUnk,
  NCOVPUI2VaxVax,
  NCOVPUI2Vax1TypeOth,
  NCOVPUI2Vax2TypeOth,
  NCOVPUI2Vax3TypeOth,
  NCOVPUI2Vax3Type,
  NCOVPUI2Vax2Type,
  NCOVPUI2Vax1Type,
  NCVDINonCairVax1Dose,
  NCVDINonCairVax2Dose,
  NCVDINonCairVax3Dose,
  NCVDINonCairVax4Dose,
  NCVDIVaxNonCairReportOther1Dose,
  NCVDIVaxNonCairReportOther2Dose,
  NCVDIVaxNonCairReportOther3Dose,
  NCVDIVaxNonCairReportOther4Dose,
  NCVDIVaxCairReportDate1Dose,
  NCVDIVaxCairReportDate2Dose,
  NCVDIVaxCairReportDate3Dose,
  NCVDIVaxCairReportDate4Dose,
  NCVDIVaxCairReportDate1DoseUnk,
  NCVDIVaxCairReportDate2DoseUnk,
  NCVDIVaxCairReportDate3DoseUnk,
  NCVDIVaxCairReportDate4DoseUnk,
  NCVDIPostVaxHospNotes,
  NCVDIPostVaxDeath,
  NCVDIPostVaxHosp,
  NCVDIPostVaxInf,
  NCVDIVaxCairType1Dose,
  NCVDIVaxCairType2Dose,
  NCVDIVaxCairType3Dose,
  NCVDIVaxCairType4Dose,
  NCVDIVaxCairTypeOther1Dose,
  NCVDIVaxCairTypeOther2Dose,
  NCVDIVaxCairTypeOther3Dose,
  NCVDIVaxCairTypeOther4Dose,
  RECORD_ID as 'DIID',
  PR_INCIDENTID as 'INSTANCEID',
  PER_ClientID as 'Person_ID',
  SECTION_INSTANCE_ID as 'UDSectionActID',
  PR_PHTYPE as 'RecordType',
  PR_DISEASE as 'Disease',
  PR_DISTRICT as 'District',
  FORM_INSTANCE_ID as 'FormInstanceID',
  FORM_NAME as 'FormName',
  FORM_DESCRIPTION as 'FormDescription',
  try_cast(FORM_CREATEDATE as datetime) as 'FormCreateDateTime'
FROM    
(
  SELECT  
    UDF.RECORD_ID, 
    UDF.FORM_INSTANCE_ID, 
    UDF.FORM_NAME, 
    UDF.FORM_DESCRIPTION, 
    UDF.FORM_CREATEDATE, 
    UDF.SECTION_INSTANCE_ID, 
    UDF.FIELD_DEF_DR AS FIELD_DEF_DR, 
    CAST(FIELD_VALUE AS VARCHAR(MAX)) AS FIELD_VALUE, 
    P.PER_ClientID, 
    I.PR_PHTYPE, 
    I.PR_DISEASE, 
    I.PR_INCIDENTID, 
    I.PR_DISTRICT
  FROM    
    dbo.[COVID_UDF_DATA] AS UDF with (nolock)
    INNER JOIN 
    dbo.[COVID_INCIDENT] AS I with (nolock)
      ON UDF.RECORD_ID = I.PR_ROWID
    INNER JOIN 
    dbo.[COVID_PERSON] AS P with (nolock)
      ON P.PER_ROWID = I.PR_PersonDR
  WHERE   
    UDF.SECTION_DEF_DR = 'NCOVPUI2Vax' AND FORM_DEF_DR = 'NCOVPUI'
) AS PivotData
PIVOT 
(
  MAX(FIELD_VALUE)
  FOR FIELD_DEF_DR IN 
  (
    NCOVPUI2Vax1Date,
    NCOVPUI2Vax2Date,
    NCOVPUI2Vax3Date,
    NCOVPUI2Vax3DateUnk,
    NCOVPUI2Vax2DateUnk,
    NCOVPUI2Vax1DateUnk,
    NCOVPUI2VaxVax,
    NCOVPUI2Vax1TypeOth,
    NCOVPUI2Vax2TypeOth,
    NCOVPUI2Vax3TypeOth,
    NCOVPUI2Vax3Type,
    NCOVPUI2Vax2Type,
    NCOVPUI2Vax1Type,
    NCVDINonCairVax1Dose,
    NCVDINonCairVax2Dose,
    NCVDINonCairVax3Dose,
    NCVDINonCairVax4Dose,
    NCVDIVaxNonCairReportOther1Dose,
    NCVDIVaxNonCairReportOther2Dose,
    NCVDIVaxNonCairReportOther3Dose,
    NCVDIVaxNonCairReportOther4Dose,
    NCVDIVaxCairReportDate1Dose,
    NCVDIVaxCairReportDate2Dose,
    NCVDIVaxCairReportDate3Dose,
    NCVDIVaxCairReportDate4Dose,
    NCVDIVaxCairReportDate1DoseUnk,
    NCVDIVaxCairReportDate2DoseUnk,
    NCVDIVaxCairReportDate3DoseUnk,
    NCVDIVaxCairReportDate4DoseUnk,
    NCVDIPostVaxHospNotes,
    NCVDIPostVaxDeath,
    NCVDIPostVaxHosp,
    NCVDIPostVaxInf,
    NCVDIVaxCairType1Dose,
    NCVDIVaxCairType2Dose,
    NCVDIVaxCairType3Dose,
    NCVDIVaxCairType4Dose,
    NCVDIVaxCairTypeOther1Dose,
    NCVDIVaxCairTypeOther2Dose,
    NCVDIVaxCairTypeOther3Dose,
    NCVDIVaxCairTypeOther4Dose
  )
) AS PivotTable
