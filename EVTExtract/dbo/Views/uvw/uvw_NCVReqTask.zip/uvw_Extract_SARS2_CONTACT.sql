CREATE VIEW [dbo].[uvw_Extract_SARS2_CONTACT]
AS

SELECT  [DIID]                                                       AS 'DIID'
        , [CONTACTID]                                                AS 'ContactID'
        , [INSTANCEID]                                               AS 'IncidentID'
        , [RECORDTYPE]                                               AS 'RECORDTYPE'
        , [RLENT_FIRSTNAME]                                          AS 'RLENT_FirstName'
        , [RLENT_LASTNAME]                                           AS 'RLENT_LastName'
        , [RLENT_MIDDLEINITIAL]                                      AS 'RLENT_MiddleInitial'
        , [RLENT_NAMESUFFIX]                                         AS 'RLENT_NameSuffix'
        , [RLENT_AGE]                                                AS 'RLENT_Age'
        , try_CONVERT(DATETIME,[RLENT_DOB])                          AS 'RLENT_DOB'
        , [RLENT_SEX]                                                AS 'RLENT_Sex'
        , [RLENT_CONTACTTYPE]                                        AS 'RLENT_ContactType'
        , try_CONVERT(DATETIME,[RLENT_DATESOFCONTACT])               AS 'RLENT_DatesOfContact'
        , [RLENT_STREETADDRESS]                                      AS 'RLENT_StreetAddress'
        , [RLENT_APARTMENT]                                          AS 'RLENT_Apartment'
        , [RLENT_CITY]                                               AS 'RLENT_City'
        , [RLENT_ZIP]                                                AS 'RLENT_Zip'
        , [RLENT_PHONE]                                              AS 'RLENT_Phone'
        , [RLENT_DISTRICT]                                           AS 'RLENT_District'
        , [RLENT_PROPHYLAXISMEDICATION]                              AS 'RLENT_ProphylaxisMedication'
        , [RLENT_INVESTIGATORDR]                                     AS 'RLENT_InvestigatorDR'
        , try_CONVERT(char,[RLENT_EXPEVENTDR])                       AS 'RLENT_ExpEventDR'
        , [RLENT_EXPEVENT]                                           AS 'RLENT_EXPEVENT'
        , [RLENT_PRIORITYDR]                                         AS 'RLENT_PriorityDR'
        , [RLENT_CLUSTERID]                                          AS 'RLENT_ClusterID'
        , [RLENT_STATUSDR]                                           AS 'RLENT_StatusDR'
        , [FOLDERID]                                                 AS 'FOLDERID'
        , [RLENT_ELECTRONICCONTACT]                                  AS 'RLENT_ELECTRONICCONTACT'
        , [RLENT_EMAIL]                                              AS 'RLENT_EMAIL'
        , [RLENT_STATE]                                              AS 'RLENT_State'
        , (
            CASE
                WHEN [RLENT_RACE] = 'Multiple Races' THEN 'Multiple Race'                                              
                ELSE [RLENT_RACE]  
            END
        )                                                            AS 'RLENT_Race'
        , [RLENT_PERSONALRECORDDR]                                   AS 'RLENT_PersonalRecordID'
        , try_CONVERT(numeric,[RLENT_PERSONALRECORDID])              AS 'RLENT_PersonalRecordIncidentID'
        , [RLENT_PERSONALRECORDTYPE]                                 AS 'RLENT_PERSONALRECORDTYPE'
        , [RLENT_CONTACTINVESTIGATIONLINKEDINCIDENTDR]               AS 'RLENT_CONTACTINVESTIGATIONLINKEDINCIDENTDR'
        , [RLENT_CONTACTINVESTIGATIONLINKEDINCIDENTID]               AS 'RLENT_CONTACTINVESTIGATIONLINKEDINCIDENTID'
FROM    dbo.[SARS2_CONTACT] with (nolock)


