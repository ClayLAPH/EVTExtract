CREATE VIEW dbo.[uvw_NCVFacSect3V01]
AS

SELECT          
		[NCVRes2BTested]
		, [NCVNumPosSymRes]
		, [NCVNegStaff]
		, [NCVNumAsymPosRes]
		,  try_CONVERT(DATETIME, [NCVDateMassTest]) AS 'NCVDateMassTest'
		, [NCVTotStaffSwab]
		, [NCVTotResSwab]
		, [NCVIndeStaff]
		, [NCVNumStaff]
		, [NCVNumPosSymStaff]
		, [NCVIndiRes]
		, [NCVStaff2Btested]
		, [NCVStaffRefuseTest]
		, [NCVResPositive]
		, [NCVTestingBy]
		, [NCVTotRes]
		, [NCVFAcTestType]
		, [NCVNumPosASymStaffUNK]
		, [NCVMassTestLab]
		, [NCVResRefuseTest]
		, [NCVPrevPosStaff]
		, [NCVNumPosResSymUNK2]
		, [NCVNumPosASymStaff]
		, [NCVNegRes]
		, [NCVPrePosRes]
		, [NCVPosStaff]
		, [NCVOBINITDATEPLANTEST]
		, [NCVOBTESTNOTES]
        , [RECORD_ID] as 'DIID'
        , [OUTB_OUTBREAKID] as 'INSTANCEID'
		, [SECTION_INSTANCE_ID] as 'UDSectionActID'
        ,  (
				CASE
					WHEN [FORM_DEF_DR] = 'NCVOBTab' THEN 'Outbreak'
					ELSE NULL
				END
			) as 'RecordType'
        , [OUTB_Disease] as 'Disease'
		, [OUTB_OutbreakNumber] AS 'OutbreakNumber'
        , [OUTB_District] as 'District'
        , [FORM_INSTANCE_ID] as 'FormInstanceID'
        , [FORM_NAME] as 'FormName'
        , [FORM_DESCRIPTION] as 'FormDescription'
        , try_CONVERT(DATETIME,[FORM_CREATEDATE]) as 'FormCreateDateTime'
FROM    (
            SELECT  UDF.[RECORD_ID]
                    , UDF.[FORM_INSTANCE_ID]
                    , UDF.[FORM_NAME]
                    , UDF.[FORM_DESCRIPTION]
                    , UDF.[FORM_CREATEDATE]
					, UDF.[FORM_DEF_DR]
					, UDF.[SECTION_INSTANCE_ID] 
                    , UDF.[FIELD_DEF_DR] AS [FIELD_DEF_DR]
                    , CAST([FIELD_VALUE] AS VARCHAR(MAX)) AS [FIELD_VALUE]
                    , O.[OUTB_Disease]
					, O.[OUTB_OutbreakNumber] 
                    , O.[OUTB_OUTBREAKID]
                    , O.[OUTB_District]
            FROM    
              dbo.[COVID_OUTBREAK_UDF_DATA] AS UDF with (nolock) 
					    INNER JOIN
              dbo.[COVID_OUTBREAK] AS O with (nolock)
                ON UDF.[RECORD_ID] = O.[OUTB_ROWID]
            WHERE   
              UDF.[SECTION_DEF_DR] = 'NCVFacSect3V01' AND [FORM_DEF_DR] = 'NCVOBTab'
        ) AS PivotData
PIVOT (
    MAX([FIELD_VALUE])
    FOR [FIELD_DEF_DR] IN (
		[NCVRes2BTested]
		, [NCVNumPosSymRes]
		, [NCVNegStaff]
		, [NCVNumAsymPosRes]
		, [NCVDateMassTest]
		, [NCVTotStaffSwab]
		, [NCVTotResSwab]
		, [NCVIndeStaff]
		, [NCVNumStaff]
		, [NCVNumPosSymStaff]
		, [NCVIndiRes]
		, [NCVStaff2Btested]
		, [NCVStaffRefuseTest]
		, [NCVResPositive]
		, [NCVTestingBy]
		, [NCVTotRes]
		, [NCVFAcTestType]
		, [NCVNumPosASymStaffUNK]
		, [NCVMassTestLab]
		, [NCVResRefuseTest]
		, [NCVPrevPosStaff]
		, [NCVNumPosResSymUNK2]
		, [NCVNumPosASymStaff]
		, [NCVNegRes]
		, [NCVPrePosRes]
		, [NCVPosStaff]
		, [NCVOBINITDATEPLANTEST]
		, [NCVOBTESTNOTES]
    )
) AS PivotTable


