CREATE VIEW dbo.[uvw_NCVFacSect2]
AS

SELECT          
		[NCVOBDeaths] 
		,(
            CASE 
                WHEN [NCVDropPrecautions]='No' THEN 'N' 
                WHEN [NCVDropPrecautions]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVDropPrecautions' 
		, (
            CASE 
                WHEN [NCVWorkQandNonQAreas]='No' THEN 'N' 
                WHEN [NCVWorkQandNonQAreas]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVWorkQandNonQAreas' 
		, (
            CASE 
                WHEN [NCVStaffDailyHealth]='No' THEN 'N' 
                WHEN [NCVStaffDailyHealth]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVStaffDailyHealth' 
		, (
            CASE 
                WHEN [NCVSocialDistRes]='No' THEN 'N' 
                WHEN [NCVSocialDistRes]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVSocialDistRes' 
		, (
            CASE 
                WHEN [NCVSociaDistanceStaff]='No' THEN 'N' 
                WHEN [NCVSociaDistanceStaff]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVSociaDistanceStaff'
		, (
            CASE 
                WHEN [NCVTwiceDailyHealht]='No' THEN 'N' 
                WHEN [NCVTwiceDailyHealht]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVTwiceDailyHealht' 
		, (
            CASE 
                WHEN [NCVContPlanPPE]='No' THEN 'N' 
                WHEN [NCVContPlanPPE]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVContPlanPPE' 
		, (
            CASE 
                WHEN [NCVContigSickStaff]='No' THEN 'N' 
                WHEN [NCVContigSickStaff]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVContigSickStaff' 
		, (
            CASE 
                WHEN [NCVInformNotOtherWork]='No' THEN 'N' 
                WHEN [NCVInformNotOtherWork]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVInformNotOtherWork' 
		, (
            CASE 
                WHEN [NCVStaffRetrainiedPPE]='No' THEN 'N' 
                WHEN [NCVStaffRetrainiedPPE]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVStaffRetrainiedPPE'
		, (
            CASE 
                WHEN [NCVControAudStaff]='No' THEN 'N' 
                WHEN [NCVControAudStaff]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVControAudStaff' 
		, (
            CASE 
                WHEN [NCVDesQuarant]='No' THEN 'N' 
                WHEN [NCVDesQuarant]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVDesQuarant' 
		, [NCVFacNoResponseExplain] 
		, (
            CASE 
                WHEN [NCVOpenAdm]='No' THEN 'N' 
                WHEN [NCVOpenAdm]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVOpenAdm' 
        , [RECORD_ID] as 'DIID'
        , [OUTB_OUTBREAKID] as 'INSTANCEID'
		, [SECTION_INSTANCE_ID] as 'UDSectionActID'
        ,  (
				CASE
					WHEN [FORM_DEF_DR] = 'NCVFacilityMonitoring' THEN 'Outbreak'
					ELSE NULL
				END
			) as 'RecordType'
        , [OUTB_Disease] as 'Disease'
		, [OUTB_OutbreakNumber] AS 'OutbreakNumber'
        , [OUTB_District] as 'District'
        , [FORM_INSTANCE_ID] as 'FormInstanceID'
        , [FORM_NAME] as 'FormName'
        , [FORM_DESCRIPTION] as 'FormDescription'
        , try_CONVERT(DATETIME,[FORM_CREATEDATE]) as 'FormCreateDateTime'
FROM    (
            SELECT  UDF.[RECORD_ID]
                    , UDF.[FORM_INSTANCE_ID]
                    , UDF.[FORM_NAME]
                    , UDF.[FORM_DESCRIPTION]
                    , UDF.[FORM_CREATEDATE]
					, UDF.[FORM_DEF_DR]
					, UDF.[SECTION_INSTANCE_ID] 
                    , UDF.[FIELD_DEF_DR] AS [FIELD_DEF_DR]
                    , CAST([FIELD_VALUE] AS VARCHAR(MAX)) AS [FIELD_VALUE]
                    , O.[OUTB_Disease]
					, O.[OUTB_OutbreakNumber] 
                    , O.[OUTB_OUTBREAKID]
                    , O.[OUTB_District]
            FROM    
              dbo.[COVID_OUTBREAK_UDF_DATA] AS UDF with (nolock) 
					    INNER JOIN 
              dbo.[COVID_OUTBREAK] AS O with (nolock)
                ON UDF.[RECORD_ID] = O.[OUTB_ROWID]
            WHERE   
              UDF.[SECTION_DEF_DR] = 'NCVFacSect2' AND [FORM_DEF_DR] = 'NCVFacilityMonitoring'
        ) AS PivotData
PIVOT (
    MAX([FIELD_VALUE])
    FOR [FIELD_DEF_DR] IN (
        [NCVOBDeaths] 
		, [NCVDropPrecautions] 
		, [NCVWorkQandNonQAreas] 
		, [NCVStaffDailyHealth] 
		, [NCVSocialDistRes] 
		, [NCVSociaDistanceStaff] 
		, [NCVTwiceDailyHealht] 
		, [NCVContPlanPPE] 
		, [NCVContigSickStaff] 
		, [NCVInformNotOtherWork] 
		, [NCVStaffRetrainiedPPE] 
		, [NCVControAudStaff] 
		, [NCVDesQuarant] 
		, [NCVFacNoResponseExplain] 
		, [NCVOpenAdm] 
    )
) AS PivotTable

GO

