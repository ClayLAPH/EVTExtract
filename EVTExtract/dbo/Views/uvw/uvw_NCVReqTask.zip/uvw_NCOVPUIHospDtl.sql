CREATE VIEW dbo.[uvw_NCOVPUIHospDtl]
AS
SELECT  try_CAST([NCOVPUIHospDtlAdmitDt] AS DATETIME) AS [NCOVPUIHospDtlAdmitDt]
        , [NCOVPUIHospDtlAdmitDiagno]
        , [NCOVPUIHospDtlCity]
        , try_CAST([NCOVPUIHospDtlDischDt] AS DATETIME) AS [NCOVPUIHospDtlDischDt]
        , [NCOVPUIHospDtlDischDiagno]
        , [NCOVPUIHospDtlName]
        , try_CAST([NCOVPUIHospDtlICUAdmitDt] AS DATETIME) AS [NCOVPUIHospDtlICUAdmitDt]
        , try_CAST([NCVPUIICUAdminDate2] AS DATETIME) AS [NCVPUIICUAdminDate2] 
        , try_CAST([NCVPUIICUAdminDate3] AS DATETIME) AS [NCVPUIICUAdminDate3] 
        , try_CAST([NCVPUIICUAdminDate4] AS DATETIME) AS [NCVPUIICUAdminDate4]  
        , try_CAST([NCVPUIICUAdminDate5] AS DATETIME) AS [NCVPUIICUAdminDate5] 
        , try_CAST([NCVPUIICUAdminDate6] AS DATETIME) AS [NCVPUIICUAdminDate6] 
        , try_CAST([NCOVPUIHospDtlICUDischDt] AS DATETIME) AS [NCOVPUIHospDtlICUDischDt]
        , try_CAST([NCVPUIICUDischDate2] AS DATETIME) AS [NCVPUIICUDischDate2] 
        , try_CAST([NCVPUIICUDischDate3] AS DATETIME) AS [NCVPUIICUDischDate3] 
        , try_CAST([NCVPUIICUDischDate4] AS DATETIME) AS [NCVPUIICUDischDate4] 
        , try_CAST([NCVPUIICUDischDate5] AS DATETIME) AS [NCVPUIICUDischDate5] 
        , try_CAST([NCVPUIICUDischDate6] AS DATETIME) AS [NCVPUIICUDischDate6]  
        , try_CAST([NCOVPUIHospDtlIntub1EndDt] AS DATETIME) AS [NCOVPUIHospDtlIntub1EndDt]
        , try_CAST([NCOVPUIHospDtlIntub2EndDt] AS DATETIME) AS [NCOVPUIHospDtlIntub2EndDt]
        , try_CAST([NCVPUIIntubateEndDate3] AS DATETIME) AS [NCVPUIIntubateEndDate3] 
        , try_CAST([NCVPUIIntubateEndDate4] AS DATETIME) AS [NCVPUIIntubateEndDate4]
        , try_CAST([NCVPUIIntubateEndDate5] AS DATETIME) AS [NCVPUIIntubateEndDate5]
        , try_CAST([NCVPUIIntubateEndDate6] AS DATETIME) AS [NCVPUIIntubateEndDate6] 
        , try_CAST([NCOVPUIHospDtlIntub1StartDt] AS DATETIME) AS [NCOVPUIHospDtlIntub1StartDt]
        , try_CAST([NCOVPUIHospDtlIntub2StartDt] AS DATETIME) AS [NCOVPUIHospDtlIntub2StartDt]
		    , try_CAST([NCVPUIIntubateStartDate3] AS DATETIME) AS [NCVPUIIntubateStartDate3]
		    , try_CAST([NCVPUIIntubateStartDate4] AS DATETIME) AS [NCVPUIIntubateStartDate4]
		    , try_CAST([NCVPUIIntubateStartDate5] AS DATETIME) AS [NCVPUIIntubateStartDate5]
		    , try_CAST([NCVPUIIntubateStartDate6] AS DATETIME) AS [NCVPUIIntubateStartDate6]
        , [NCOVPUIHospDtlMRN]
        , (
            CASE 
                WHEN [NCOVPUIHospDtlICU]='No' THEN 'N' 
                WHEN [NCOVPUIHospDtlICU]='Yes' THEN 'Y' 
                WHEN [NCOVPUIHospDtlICU]='Unknown' THEN 'U' 
                ELSE NULL 
            END
        ) AS 'NCOVPUIHospDtlICU'
        , (
            CASE 
                WHEN [NCOVPUIHospDtlIntub]='No' THEN 'N' 
                WHEN [NCOVPUIHospDtlIntub]='Yes' THEN 'Y' 
                WHEN [NCOVPUIHospDtlIntub]='Unknown' THEN 'U' 
                ELSE NULL 
            END
        ) AS 'NCOVPUIHospDtlIntub'
        , [NCOVPUIHospDtlState]
        , [NCOVPUIHospDtlAddr]
        , [NCOVPUIHospDtlPhone]
        , [NCOVPUIHospDtlZip]
        , [RECORD_ID] as 'DIID'
        , [PR_INCIDENTID] as 'INSTANCEID'
        , [PER_ClientID] as 'Person_ID'
		    , [SECTION_INSTANCE_ID] as 'UDSectionActID'
        , [PR_PHTYPE] as 'RecordType'
        , [PR_DISEASE] as 'Disease'
        , [PR_DISTRICT] as 'District'
        , [FORM_INSTANCE_ID] as 'FormInstanceID'
        , [FORM_NAME] as 'FormName'
        , [FORM_DESCRIPTION] as 'FormDescription'
        , try_CONVERT(DATETIME,[FORM_CREATEDATE]) as 'FormCreateDateTime'
FROM    (
            SELECT  UDF.[RECORD_ID]
                    , UDF.[FORM_INSTANCE_ID]
                    , UDF.[FORM_NAME]
                    , UDF.[FORM_DESCRIPTION]
                    , UDF.[FORM_CREATEDATE]
					, UDF.[SECTION_INSTANCE_ID] 
                    , UDF.[FIELD_DEF_DR] AS [FIELD_DEF_DR]
                    , CAST([FIELD_VALUE] AS VARCHAR(MAX)) AS [FIELD_VALUE]
                    , P.[PER_ClientID]
                    , I.[PR_PHTYPE]
                    , I.[PR_DISEASE]
                    , I.[PR_INCIDENTID]
                    , I.[PR_DISTRICT]
            FROM    
              dbo.[COVID_UDF_DATA] AS UDF with (nolock) 
				      INNER JOIN 
              dbo.[COVID_INCIDENT] AS I with (nolock)
                ON UDF.[RECORD_ID] = I.[PR_ROWID]
              INNER JOIN 
              dbo.[COVID_PERSON] AS P with (nolock)
                ON P.[PER_ROWID] = I.[PR_PersonDR]
            WHERE   UDF.[SECTION_DEF_DR] = 'NCOVPUIHospDtl'  AND [FORM_DEF_DR] = 'NCOVPUI'
        ) AS PivotData
PIVOT (
    MAX([FIELD_VALUE])
    FOR [FIELD_DEF_DR] IN (
        [NCOVPUIHospDtlAdmitDt]
        , [NCOVPUIHospDtlAdmitDiagno]
        , [NCOVPUIHospDtlCity]
        , [NCOVPUIHospDtlDischDt]
        , [NCOVPUIHospDtlDischDiagno]
        , [NCOVPUIHospDtlName]
        , [NCOVPUIHospDtlICUAdmitDt]
        , [NCOVPUIHospDtlICUDischDt]
        , [NCOVPUIHospDtlIntub1EndDt]
        , [NCOVPUIHospDtlIntub2EndDt]
        , [NCOVPUIHospDtlIntub1StartDt]
        , [NCOVPUIHospDtlIntub2StartDt]
        , [NCOVPUIHospDtlMRN]
        , [NCOVPUIHospDtlICU]
        , [NCOVPUIHospDtlIntub]
        , [NCOVPUIHospDtlState]
        , [NCOVPUIHospDtlAddr]
        , [NCOVPUIHospDtlPhone]
        , [NCOVPUIHospDtlZip]
        , [NCVPUIICUAdminDate2]
        , [NCVPUIICUAdminDate3]
        , [NCVPUIICUAdminDate4]
        , [NCVPUIICUAdminDate5]
        , [NCVPUIICUAdminDate6]
        , [NCVPUIICUDischDate2]
        , [NCVPUIICUDischDate3]
        , [NCVPUIICUDischDate4]
        , [NCVPUIICUDischDate5]
        , [NCVPUIICUDischDate6]
        , [NCVPUIIntubateEndDate3]
        , [NCVPUIIntubateEndDate4]
		, [NCVPUIIntubateEndDate5]
		, [NCVPUIIntubateEndDate6]
		, [NCVPUIIntubateStartDate3]
		, [NCVPUIIntubateStartDate4]
		, [NCVPUIIntubateStartDate5]
		, [NCVPUIIntubateStartDate6]
    )
) AS PivotTable
