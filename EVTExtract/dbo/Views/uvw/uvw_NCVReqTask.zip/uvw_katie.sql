CREATE VIEW dbo.[uvw_Katie]
AS
SELECT  
		I.[PR_INCIDENTID]												   AS 'IncidentID'
		, L.[LabReportID]  												   AS 'LabReportID'
        , L.[HL7FILENAME]                                                  AS 'HL7FILENAME'
        , L.[RESULTUNIT]                                                   AS 'UNIT'
        , L.[RESULTVALUE]                                                  AS 'RESULT'
        , L.[ABNORMALFLAG]                                                 AS 'ABNORMALFLAG'
		, (
			CASE
			WHEN L.[ISFROMHL7] = 0 THEN 'False'
			WHEN L.[ISFROMHL7] = 1 THEN 'True'
			ELSE NULL 
			END
		) AS 'ISFROMHL7'
        ,  (
			CASE
			WHEN L.[LOCALORGANISMCODE] = '' THEN L.[LOCALORGANISMCODETEXT]
			WHEN L.[LOCALORGANISMCODE] IS NULL THEN L.[LOCALORGANISMCODETEXT]
			ELSE L.[LOCALORGANISMCODE]
			END
			)						                                       AS 'LOCALORGANISMCODE'
        , (
			CASE
			WHEN L.[LOCALORGANISMDESCRIPTION] = '' THEN L.[LOCALORGANISMDESCRIPTIONTEXT]
			WHEN L.[LOCALORGANISMDESCRIPTION] IS NULL THEN L.[LOCALORGANISMDESCRIPTIONTEXT]
			ELSE L.[LOCALORGANISMDESCRIPTION]
			END
			)						                                       AS 'LOCALORGANISMDESCRIPTION'
        , L.[LOCALTESTCODE]                                                AS 'LOCALTESTCODE'
        , L.[LOCALTESTDESCRIPTION]                                         AS 'LOCALTESTDESCRIPTION'
        , L.[NOTES]                                                        AS 'NOTES'
        , L.[ORGANISMCODE]                                                 AS 'ORGANISMCODE'
        , L.[ORGANISMDESCRIPTION]                                          AS 'ORGANISMDESCRIPTION'
        , L.[PATIENTNAME]                                                  AS 'PATIENTNAME'
        , L.[PERFORMINGFACILITYID]                                         AS 'PERFORMINGFACILITYID'
        , L.[PROVIDERNAME]                                                 AS 'PROVIDERNAME'
        , L.[PROVIDERADDRESS]                                              AS 'PROVIDERADDRESS'
        , L.[ACCESSIONNUMBER]                                              AS 'ACCESSIONNUMBER'
        , L.[REFERENCERANGE]                                               AS 'REFERENCERANGE'
        , L.[TESTDESCRIPTION]                                              AS 'RESULTEDTEXT'
        , L.[PROVIDERZIP]                                                  AS 'PROVIDERZip'
        , L.[PROVIDERPHONE]                                                AS 'PROVIDERPHONE'
        , L.[PROVIDERID]                                                   AS 'PROVIDERID'
        , L.[PROVIDERCITY]                                                 AS 'PROVIDERCity'
        , L.[PROVIDERSTATE]                                                AS 'PROVIDERState'
        , L.[FACILITYNAME]                                                 AS 'FACILITYNAME'
        , L.[FACILITYID]                                                   AS 'FACILITYID'
        , L.[IMPORTSTATUS]                                                 AS 'IMPORTSTATUS'
       , L.[ORGANISMCODINGSYSTEM]                                         AS 'ORGANISMCODINGSYSTEM'
        , L.[FACILITYADDRESS]                                              AS 'FACILITYADDRESS'
        , L.[FACILITYCITY]                                                 AS 'FACILITYCity'
		, (
			CASE
			WHEN L.[ORDERSTATUS] = 'A' THEN 'Some, but not all, results available'
			WHEN L.[ORDERSTATUS] = 'C' THEN 'Correction to results'
			WHEN L.[ORDERSTATUS] = 'F' THEN 'Final results; results stored and verified. Can only be changed with a corrected result'
			WHEN L.[ORDERSTATUS] = 'P' THEN 'Preliminary: A verified early result is available, final results not yet obtained'
			WHEN L.[ORDERSTATUS] = 'U' THEN 'Results status change to Final without re-transmitting results already sent as preliminary.'
			WHEN L.[ORDERSTATUS] = 'X' THEN 'No results available; Order canceled'
			ELSE L.[ORDERSTATUS] 
			END
		) AS 'ORDERRESULTSTATUS'
        , L.[FACILITYZIP]                                                  AS 'FACILITYZip'
        , L.[FACILITYPHONE]                                                AS 'FACILITYPHONE'
        , try_CONVERT(DATETIME,L.[RESULTDATE])                             AS 'RESULTDATE'
        , (
			CASE
			WHEN L.[RESULTEDORGANISM]= '193213' THEN 'Positive (qualifier value)'        
			WHEN L.[RESULTEDORGANISM]= '315017' THEN 'Detected (qualifier value)'        
			ELSE L.[RESULTEDORGANISM]
			END
		) AS 'RESULTEDORGANISM'
        , L.[RESULTTEXT]                                                   AS 'RESULTTEXT'
        , L.[SEROLOGY]                                                     AS 'SEROLOGY'
        , try_CONVERT(DATETIME,L.[SPECCOLLECTEDDATE])                      AS 'SPECCOLLECTEDDATE'
        , (
			CASE
			WHEN L.[SPECIMENSOURCE] IS NULL THEN L.[SPECIMENSOURCETEXT]
			ELSE L.[SPECIMENSOURCE]
			END
			)															  AS 'SPECIMENSOURCE'
        , try_CONVERT(DATETIME,L.[SPECRECEIVEDDATE])                       AS 'SPECRECEIVEDDATE'
        , L.[TESTCODE]                                                     AS 'TESTCODE'
		, P.[PER_ClientID]                                                     AS 'Person_ID'
		, try_CONVERT(DATETIME,P.[PER_DOB])                                    AS 'DOB'       
        , P.[PER_ETHNICITY]                                          AS 'Ethnicity'
        , (CASE 
			WHEN P.[PER_RACE] = 'Multiple Races' THEN 'Multiple Race'
			ELSE P.[PER_RACE]
			END
			)
																	 AS 'Reported_Race'
 , P.[PER_LASTNAME]                                           AS 'Last_Name'
        , P.[PER_FIRSTNAME]                                          AS 'First_Name'
        , P.[PER_MIDDLENAME]                                         AS 'Middle_Name'
        , P.[PER_STREETADDRESS]                                      AS 'Street_Address'
        , P.[PER_CITY]                                               AS 'City'
        , P.[PER_STATE]                                              AS 'State'
        , P.[PER_ZIP]                                                AS 'Zip'
        , P.[PER_COUNTY]                                             AS 'County'
        , P.[PER_LATITUDE]                                           AS 'Latitude'
        , P.[PER_LONGITUDE]                                          AS 'Longitude'
        , P.[PER_COUNTYOFRESIDENCE]                                  AS 'County_of_Residence'
        , P.[PER_COUNTRY_NAME]                                       AS 'Country_of_Residence'
        , P.[PER_SEX]                                                AS 'Sex'
        , P.[PER_EMAIL]                                              AS 'E_mail'
        , P.[PER_HOMEPHONE]                                          AS 'Home_Telephone'
        , P.[PER_ADDRESSSTANDARDIZED]                                AS 'Address_Standardized'
        , P.[PER_APARTMENT]                                          AS 'Apartment_Number'
        , P.[PER_CELLPHONE]                                          AS 'Cellular_Phone_Pager'
        , P.[PER_OCCUPATION]                                         AS 'Occupation'
        , I.[PR_INCIDENTID]                                          AS 'Incident_ID'
        , I.[Age]                                                    AS 'Age'
        , I.[PR_CENSUSTRACT]                                         AS 'Census_Tract'
        , (
            CASE
                WHEN I.[PR_ISPREGNANT] = 0 THEN 'N'
                WHEN I.[PR_ISPREGNANT] = 1 THEN 'Y' 
				WHEN P.[PER_SEX] IS NOT NULL AND P.[PER_SEX] <> 'Male' AND I.[PR_ISPREGNANT] IS NULL THEN 'U'
				ELSE NULL
            END
		 )                                                           AS 'Is_Pregnant'
        , (
			CASE
			WHEN I.[Imported_Status] = 819 THEN 'Indigenous'
			WHEN I.[Imported_Status] = 820 THEN 'International'
			WHEN I.[Imported_Status] = 821 THEN 'International/Out Of State/Other Jurisdiction (unknown)'
			WHEN I.[Imported_Status] = 822 THEN 'Other Jurisdiction'
			WHEN I.[Imported_Status] = 823 THEN 'Out Of State'
			WHEN I.[Imported_Status] = 824 THEN 'Unknown'
			ELSE NULL
			END
		)					                                         AS 'Imported_Status'
        , I.[Created_By]                                             AS 'Created_By'
        , I.[PR_PHTYPE]                                              AS 'Record_Type'
        , I.[PR_DISEASE]                                             AS 'Disease'
        , I.[PR_DISTRICT]                                            AS 'District'
        , I.[PR_PROCESSSTATUS]                                       AS 'Process_Status'
        , I.[PR_RESOLUTIONSTATUS]                                    AS 'Resolution_Status'
        , I.[Health_District_Number]                                 AS 'Health_District_Number'
        , I.[Report_Source]                                          AS 'Report_Source'
        , try_CONVERT(DATETIME,I.[PR_CREATEDATE])                    AS 'Date_Created'
        , try_CONVERT(DATETIME,I.[PR_DATEOFLABREPORT])               AS 'Date_of_Lab_Report'
        , try_CONVERT(DATETIME,I.[PR_DATEINVESTIGATORRECEIVED])      AS 'Date_Received'
        , try_CONVERT(DATETIME,I.[PR_EPISODEDATE])                   AS 'Episode_Date'
        , I.[Lab_Report_Test_Name]                                   AS 'Lab_Report_Test_Name'
        , try_CONVERT(DATETIME,I.[PR_LABSPECIMENCOLLECTEDDATE])      AS 'Lab_Specimen_Collection_Date'
        , try_CONVERT(DATETIME,I.[PR_LABSPECIMENRESULTDATE])         AS 'Lab_Specimen_Result_Date'
        , I.[PR_LABORATORY]                                          AS 'Laboratory'
        , I.[Medical_Record_Number]                                  AS 'Medical_Record_Number'
        , I.[Most_Recent_Lab_Result]                                 AS 'Most_Recent_Lab_Result'
        , I.[Provider_Name]                                          AS 'Provider_Name'
FROM    dbo.[COVID_LAB] AS L with (nolock) 
        INNER JOIN
        dbo.[COVID_INCIDENT] AS I with (nolock)
			  ON L.[IncidentID] = CAST(I.[PR_INCIDENTID] as varchar(50))
	  	  INNER JOIN 
        dbo.[COVID_PERSON] AS P with (nolock) 
	      ON P.[PER_RowID] = I.[PR_PersonDR] 
UNION ALL	
SELECT  
		I.[PR_INCIDENTID]												   AS 'IncidentID'
		, L.[LabReportID]  												   AS 'LabReportID'
        , L.[HL7FILENAME]                                                  AS 'HL7FILENAME'
        , L.[RESULTUNIT]                                                   AS 'UNIT'
        , L.[RESULTVALUE]                                                  AS 'RESULT'
        , L.[ABNORMALFLAG]                                                 AS 'ABNORMALFLAG'
		, (
			CASE
			WHEN L.[ISFROMHL7] = 0 THEN 'False'
			WHEN L.[ISFROMHL7] = 1 THEN 'True'
			ELSE NULL 
			END
		) AS 'ISFROMHL7'
        ,  (
			CASE
			WHEN L.[LOCALORGANISMCODE] = '' THEN L.[LOCALORGANISMCODETEXT]
			WHEN L.[LOCALORGANISMCODE] IS NULL THEN L.[LOCALORGANISMCODETEXT]
			ELSE L.[LOCALORGANISMCODE]
			END
			)						                                       AS 'LOCALORGANISMCODE'
        , (
			CASE
			WHEN L.[LOCALORGANISMDESCRIPTION] = '' THEN L.[LOCALORGANISMDESCRIPTIONTEXT]
			WHEN L.[LOCALORGANISMDESCRIPTION] IS NULL THEN L.[LOCALORGANISMDESCRIPTIONTEXT]
			ELSE L.[LOCALORGANISMDESCRIPTION]
			END
			)						                                       AS 'LOCALORGANISMDESCRIPTION'
        , L.[LOCALTESTCODE]                                                AS 'LOCALTESTCODE'
        , L.[LOCALTESTDESCRIPTION]                                         AS 'LOCALTESTDESCRIPTION'
        , L.[NOTES]                                                        AS 'NOTES'
        , L.[ORGANISMCODE]                                                 AS 'ORGANISMCODE'
        , L.[ORGANISMDESCRIPTION]                                          AS 'ORGANISMDESCRIPTION'
        , L.[PATIENTNAME]                                                  AS 'PATIENTNAME'
        , L.[PERFORMINGFACILITYID]                                         AS 'PERFORMINGFACILITYID'
        , L.[PROVIDERNAME]                                                 AS 'PROVIDERNAME'
        , L.[PROVIDERADDRESS]                                              AS 'PROVIDERADDRESS'
        , L.[ACCESSIONNUMBER]                                              AS 'ACCESSIONNUMBER'
        , L.[REFERENCERANGE]                                               AS 'REFERENCERANGE'
        , L.[TESTDESCRIPTION]                                              AS 'RESULTEDTEXT'
        , L.[PROVIDERZIP]                                                  AS 'PROVIDERZip'
        , L.[PROVIDERPHONE]                                                AS 'PROVIDERPHONE'
        , L.[PROVIDERID]                                                   AS 'PROVIDERID'
        , L.[PROVIDERCITY]                                                 AS 'PROVIDERCity'
        , L.[PROVIDERSTATE]                                                AS 'PROVIDERState'
        , L.[FACILITYNAME]                                                 AS 'FACILITYNAME'
        , L.[FACILITYID]                                                   AS 'FACILITYID'
        , L.[IMPORTSTATUS]                                                 AS 'IMPORTSTATUS'
       , L.[ORGANISMCODINGSYSTEM]                                         AS 'ORGANISMCODINGSYSTEM'
        , L.[FACILITYADDRESS]                                              AS 'FACILITYADDRESS'
        , L.[FACILITYCITY]                                                 AS 'FACILITYCity'
		, (
			CASE
			WHEN L.[ORDERSTATUS] = 'A' THEN 'Some, but not all, results available'
			WHEN L.[ORDERSTATUS] = 'C' THEN 'Correction to results'
			WHEN L.[ORDERSTATUS] = 'F' THEN 'Final results; results stored and verified. Can only be changed with a corrected result'
			WHEN L.[ORDERSTATUS] = 'P' THEN 'Preliminary: A verified early result is available, final results not yet obtained'
			WHEN L.[ORDERSTATUS] = 'U' THEN 'Results status change to Final without re-transmitting results already sent as preliminary.'
			WHEN L.[ORDERSTATUS] = 'X' THEN 'No results available; Order canceled'
			ELSE L.[ORDERSTATUS] 
			END
		) AS 'ORDERRESULTSTATUS'
        , L.[FACILITYZIP]                                                  AS 'FACILITYZip'
        , L.[FACILITYPHONE]                                                AS 'FACILITYPHONE'
        , try_CONVERT(DATETIME,L.[RESULTDATE])                             AS 'RESULTDATE'
        , (
			CASE
			WHEN L.[RESULTEDORGANISM]= '193213' THEN 'Positive (qualifier value)'        
			WHEN L.[RESULTEDORGANISM]= '315017' THEN 'Detected (qualifier value)'        
			ELSE L.[RESULTEDORGANISM]
			END
		) AS 'RESULTEDORGANISM'
        , L.[RESULTTEXT]                                                   AS 'RESULTTEXT'
        , L.[SEROLOGY]                                                     AS 'SEROLOGY'
        , try_CONVERT(DATETIME,L.[SPECCOLLECTEDDATE])                      AS 'SPECCOLLECTEDDATE'
        , (
			CASE
			WHEN L.[SPECIMENSOURCE] IS NULL THEN L.[SPECIMENSOURCETEXT]
			ELSE L.[SPECIMENSOURCE]
			END
			)															  AS 'SPECIMENSOURCE'
        , try_CONVERT(DATETIME,L.[SPECRECEIVEDDATE]) AS 'SPECRECEIVEDDATE'
        , L.[TESTCODE]                                                     AS 'TESTCODE'
		, P.[PER_ClientID]                                             AS 'Person_ID'
		, try_CONVERT(DATETIME,P.[PER_DOB])                             AS 'DOB'       
        , P.[PER_ETHNICITY]                                          AS 'Ethnicity'
        , (CASE 
			WHEN P.[PER_RACE] = 'Multiple Races' THEN 'Multiple Race'
			ELSE P.[PER_RACE]
			END
			)
																	 AS 'Reported_Race'
 , P.[PER_LASTNAME]                                           AS 'Last_Name'
        , P.[PER_FIRSTNAME]                                          AS 'First_Name'
        , P.[PER_MIDDLENAME]                                         AS 'Middle_Name'
        , P.[PER_STREETADDRESS]                                      AS 'Street_Address'
        , P.[PER_CITY]                                               AS 'City'
        , P.[PER_STATE]                                              AS 'State'
        , P.[PER_ZIP]                                                AS 'Zip'
        , P.[PER_COUNTY]                                             AS 'County'
        , P.[PER_LATITUDE]                                           AS 'Latitude'
        , P.[PER_LONGITUDE]                                          AS 'Longitude'
        , P.[PER_COUNTYOFRESIDENCE]                                  AS 'County_of_Residence'
        , P.[PER_COUNTRY_NAME]                                       AS 'Country_of_Residence'
        , P.[PER_SEX]                                                AS 'Sex'
        , P.[PER_EMAIL]                                              AS 'E_mail'
        , P.[PER_HOMEPHONE]                                          AS 'Home_Telephone'
        , P.[PER_ADDRESSSTANDARDIZED]                                AS 'Address_Standardized'
        , P.[PER_APARTMENT]                                          AS 'Apartment_Number'
        , P.[PER_CELLPHONE]                                          AS 'Cellular_Phone_Pager'
        , P.[PER_OCCUPATION]                                         AS 'Occupation'
        , I.[PR_INCIDENTID]                                          AS 'Incident_ID'
        , I.[Age]                                                    AS 'Age'
        , I.[PR_CENSUSTRACT]                                         AS 'Census_Tract'
        , (
            CASE
                WHEN I.[PR_ISPREGNANT] = 0 THEN 'N'
                WHEN I.[PR_ISPREGNANT] = 1 THEN 'Y' 
				WHEN P.[PER_SEX] IS NOT NULL AND P.[PER_SEX] <> 'Male' AND I.[PR_ISPREGNANT] IS NULL THEN 'U'
				ELSE NULL
            END
		 )                                                           AS 'Is_Pregnant'
        , (
			CASE
			WHEN I.[Imported_Status] = 819 THEN 'Indigenous'
			WHEN I.[Imported_Status] = 820 THEN 'International'
			WHEN I.[Imported_Status] = 821 THEN 'International/Out Of State/Other Jurisdiction (unknown)'
			WHEN I.[Imported_Status] = 822 THEN 'Other Jurisdiction'
			WHEN I.[Imported_Status] = 823 THEN 'Out Of State'
			WHEN I.[Imported_Status] = 824 THEN 'Unknown'
			ELSE NULL
			END
		)					                                         AS 'Imported_Status'
        , I.[Created_By]                                             AS 'Created_By'
        , I.[PR_PHTYPE]                                              AS 'Record_Type'
        , I.[PR_DISEASE]                                             AS 'Disease'
        , I.[PR_DISTRICT]                                            AS 'District'
        , I.[PR_PROCESSSTATUS]                                       AS 'Process_Status'
        , I.[PR_RESOLUTIONSTATUS]                                    AS 'Resolution_Status'
        , I.[Health_District_Number]                                 AS 'Health_District_Number'
        , I.[Report_Source]                                          AS 'Report_Source'
        , try_CONVERT(DATETIME,I.[PR_CREATEDATE])                    AS 'Date_Created'
        , try_CONVERT(DATETIME,I.[PR_DATEOFLABREPORT])               AS 'Date_of_Lab_Report'
        , try_CONVERT(DATETIME,I.[PR_DATEINVESTIGATORRECEIVED])      AS 'Date_Received'
        , try_CONVERT(DATETIME,I.[PR_EPISODEDATE])                   AS 'Episode_Date'
        , I.[Lab_Report_Test_Name]                                   AS 'Lab_Report_Test_Name'
        , try_CONVERT(DATETIME,I.[PR_LABSPECIMENCOLLECTEDDATE])      AS 'Lab_Specimen_Collection_Date'
        , try_CONVERT(DATETIME,I.[PR_LABSPECIMENRESULTDATE])         AS 'Lab_Specimen_Result_Date'
        , I.[PR_LABORATORY]                                          AS 'Laboratory'
        , I.[Medical_Record_Number]                                  AS 'Medical_Record_Number'
        , I.[Most_Recent_Lab_Result]                                 AS 'Most_Recent_Lab_Result'
        , I.[Provider_Name]                                          AS 'Provider_Name'
FROM    
  dbo.[SARS2_LAB] AS L with (nolock) 
  INNER JOIN 
  dbo.SARS2_INCIDENT_VIEW AS I with (nolock)
	ON 
    L.[IncidentID] = CAST(I.[PR_INCIDENTID] as varchar(50))
	INNER JOIN 
  dbo.[SARS2_PERSON] AS P with (nolock) 
	        ON P.[PER_RowID] = I.[PR_PersonDR] 
	