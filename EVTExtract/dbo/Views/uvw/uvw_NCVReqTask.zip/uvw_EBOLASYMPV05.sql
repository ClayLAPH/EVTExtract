CREATE VIEW dbo.[uvw_EbolaSympV05]
AS
SELECT    
		(
            CASE 
                WHEN [NCVAbdPain] ='No' THEN 'N' 
                WHEN [NCVAbdPain] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVAbdPain' 
		, try_cast([ADSSAssessmentDate] AS DATETIME) AS 'ADSSAssessmentDate'
		, [ADSSAMPM2]
		, (
            CASE 
                WHEN [NCVChills] ='No' THEN 'N' 
                WHEN [NCVChills] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVChills' 
		, (
            CASE 
                WHEN [EbolaSympCmplnt] ='No' THEN 'N' 
                WHEN [EbolaSympCmplnt] ='Yes' THEN 'Y' 
				WHEN [EbolaSympCmplnt] = 'Unknown' THEN 'U'
                ELSE NULL 
            END
        ) AS 'EbolaSympCmplnt'
		, (
            CASE 
                WHEN [NCVCaugh] ='No' THEN 'N' 
                WHEN [NCVCaugh] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVCaugh' 
		, (
            CASE 
                WHEN [NCVDiarrhea] ='No' THEN 'N' 
                WHEN [NCVDiarrhea]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVDiarrhea' 
		, (
            CASE 
                WHEN [NCVNSAID] ='No' THEN 'N' 
                WHEN [NCVNSAID] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVNSAID' 
		, (
            CASE 
                WHEN [NCVHeadache]='No' THEN 'N' 
                WHEN [NCVHeadache]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVHeadache'
		, [NCVServiceDet]
		, [ADSSMeasTempF]
		, (
            CASE 
                WHEN [NCVMuscle] ='No' THEN 'N' 
                WHEN [NCVMuscle] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVMuscle' 
		, [NCVOther]
		, (
            CASE 
                WHEN [NCVSOB]='No' THEN 'N' 
                WHEN [NCVSOB]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVSOB' 
		, (
            CASE 
                WHEN [NCVSoreThroat]='No' THEN 'N' 
                WHEN [NCVSoreThroat]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVSoreThroat'
		, (
            CASE 
                WHEN [NCVServiceNeeds]='No' THEN 'N' 
                WHEN [NCVServiceNeeds]='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVServiceNeeds' 
		, (
            CASE 
                WHEN [EbolaSympSymptomatic] ='No' THEN 'N' 
                WHEN [EbolaSympSymptomatic] ='Yes' THEN 'Y' 
				WHEN [EbolaSympSymptomatic] = 'Unknown' THEN 'U'
                ELSE NULL 
            END
        ) AS 'EbolaSympSymptomatic'
		, (
            CASE 
                WHEN [NCVVomiting] ='No' THEN 'N' 
                WHEN [NCVVomiting] ='Yes' THEN 'Y' 
                ELSE NULL 
            END
        ) AS 'NCVVomiting' 
        , [RECORD_ID] as 'DIID'
        , [PR_INCIDENTID] as 'INSTANCEID'
        , [PER_ClientID] as 'Person_ID'
		, [SECTION_INSTANCE_ID] as 'UDSectionActID'
        , [PR_PHTYPE] as 'RecordType'
        , [PR_DISEASE] as 'Disease'
        , [PR_DISTRICT] as 'District'
        , [FORM_INSTANCE_ID] as 'FormInstanceID'
        , [FORM_NAME] as 'FormName'
        , [FORM_DESCRIPTION] as 'FormDescription'
        , try_CONVERT(DATETIME,[FORM_CREATEDATE]) as 'FormCreateDateTime'
FROM    (
            SELECT  UDF.[RECORD_ID]
                    , UDF.[FORM_INSTANCE_ID]
                    , UDF.[FORM_NAME]
                    , UDF.[FORM_DESCRIPTION]
                    , UDF.[FORM_CREATEDATE]
					, UDF.[SECTION_INSTANCE_ID] 
                    , UDF.[FIELD_DEF_DR] AS [FIELD_DEF_DR]
                    , CAST([FIELD_VALUE] AS VARCHAR(MAX)) AS [FIELD_VALUE]
                    , P.[PER_ClientID]
                    , I.[PR_PHTYPE]
                    , I.[PR_DISEASE]
                    , I.[PR_INCIDENTID]
                    , I.[PR_DISTRICT]
               FROM    
                dbo.[COVID_UDF_DATA] AS UDF with (nolock)
                INNER JOIN 
                dbo.[COVID_INCIDENT] AS I with (nolock)
                ON 
                  UDF.[RECORD_ID] = I.[PR_ROWID]
                INNER JOIN 
                dbo.[COVID_PERSON] AS P with (nolock)
                ON 
                  P.[PER_ROWID] = I.[PR_PersonDR]
            WHERE   UDF.[SECTION_DEF_DR] = 'EbolaSympV05' AND [FORM_DEF_DR] = 'EbolaV05'
        ) AS PivotData
PIVOT (
    MAX([FIELD_VALUE])
    FOR [FIELD_DEF_DR] IN (
       [NCVAbdPain]
		, [ADSSAssessmentDate]
		, [ADSSAMPM2]
		, [NCVChills]
		, [EbolaSympCmplnt]
		, [NCVCaugh]
		, [NCVDiarrhea]
		, [NCVNSAID]
		, [NCVHeadache]
		, [NCVServiceDet]
		, [ADSSMeasTempF]
		, [NCVMuscle]
		, [NCVOther]
		, [NCVSOB]
		, [NCVSoreThroat]
		, [NCVServiceNeeds]
		, [EbolaSympSymptomatic]
		, [NCVVomiting]
    )
) AS PivotTable

GO
