create view dbo.uvw_Extract_COVID_OUTBREAK_PROCESS_STATUS_HISTORY as
select
  OUTB_RowID, 
  AUD_ID, 
  AUD_OldValue, 
  AUD_NewValue, 
  AUD_ActionDate, 
  AUD_Username
from    
  dbo.COVID_OUTBREAK_PROCESS_STATUS_HISTORY with (nolock)
